<?php
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/activity_log.php';

$db = db();
$user = require_login($db);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

verify_csrf();
$topicId = (int)(isset($_POST['topic_id']) ? $_POST['topic_id'] : 0);
$body = trim(isset($_POST['body']) ? $_POST['body'] : '');
$parentId = (int)(isset($_POST['parent_id']) ? $_POST['parent_id'] : 0);

if ($topicId <= 0 || $body === '') {
    header('Location: topic.php?id=' . $topicId);
    exit;
}

$parentValue = null;
if ($parentId > 0) {
    $pstmt = $db->prepare('SELECT id FROM replies WHERE id = :id AND topic_id = :t');
    $pstmt->execute([
        ':id' => $parentId,
        ':t' => $topicId,
    ]);
    if ($pstmt->fetch(PDO::FETCH_ASSOC)) {
        $parentValue = $parentId;
    }
}

$stmt = $db->prepare('INSERT INTO replies (topic_id, user_id, parent_id, body, created_at)
                      VALUES (:t, :u, :p, :b, :c)');
$stmt->execute([
    ':t' => $topicId,
    ':u' => $user['id'],
    ':p' => $parentValue,
    ':b' => $body,
    ':c' => date('Y-m-d H:i:s'),
]);

$replyId = (int)$db->lastInsertId();
log_action('reply_create', (int)$user['id'], $user['username'], 'reply', $replyId, array(
    'topic_id' => $topicId,
    'parent_id' => $parentValue,
));

header('Location: topic.php?id=' . $topicId);
exit;
