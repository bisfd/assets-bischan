<?php 
//ini_set('display_errors', '1');
//ini_set('display_startup_errors', '1');
//error_reporting(E_ALL);
    require_once __DIR__ . '/lib/db.php';
    require_once __DIR__ . '/lib/auth.php';
    $db = db();
    $user = current_user($db);
    $uploadMessage = '';
    $uploadError = '';
    $get_id = 0;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        verify_csrf();
        if (!$user) {
            http_response_code(403);
            $uploadError = 'Нужно войти в аккаунт, чтобы менять аватар.';
        } else {
            $get_id = (int)(isset($_POST['user_id']) ? $_POST['user_id'] : 0);
            if ($get_id !== (int)$user['id']) {
                http_response_code(403);
                $uploadError = 'Нельзя менять аватар другого пользователя.';
            } elseif (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
                $uploadError = 'Не удалось загрузить файл.';
            } else {
                $maxSize = 2 * 1024 * 1024;
                if ($_FILES['avatar']['size'] > $maxSize) {
                    $uploadError = 'Файл слишком большой. Максимум 2 МБ.';
                } else {
                    $tmp = $_FILES['avatar']['tmp_name'];
                    $finfo = new finfo(FILEINFO_MIME_TYPE);
                    $mime = $finfo->file($tmp);
                    $allowed = array(
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/gif' => 'gif',
                        'image/webp' => 'webp',
                    );
                    if (!isset($allowed[$mime])) {
                        $uploadError = 'Неподдерживаемый тип файла.';
                    } elseif (!@getimagesize($tmp)) {
                        $uploadError = 'Файл не является изображением.';
                    } else {
                        $ext = $allowed[$mime];
                        $filename = 'user_' . (int)$user['id'] . '_' . bin2hex(secure_random_bytes(8)) . '.' . $ext;
                        $targetPath = __DIR__ . '/avatars/' . $filename;
                        if (!move_uploaded_file($tmp, $targetPath)) {
                            $uploadError = 'Не удалось сохранить файл.';
                        } else {
                            $oldAvatar = isset($user['avatar']) ? (string)$user['avatar'] : '';
                            if ($oldAvatar !== '' && $oldAvatar !== 'Default.jpg') {
                                $oldPath = __DIR__ . '/avatars/' . basename($oldAvatar);
                                if (is_file($oldPath)) {
                                    @unlink($oldPath);
                                }
                            }
                            $avatarColumn = user_avatar_column($db);
                            $stmt = $db->prepare('UPDATE users SET ' . $avatarColumn . ' = :a WHERE id = :id');
                            $stmt->execute(array(
                                ':a' => $filename,
                                ':id' => (int)$user['id'],
                            ));
                            $uploadMessage = 'Аватар обновлен.';
                            $user = current_user($db);
                        }
                    }
                }
            }
        }
    }

    if ($get_id <= 0) {
        $get_id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    }
    if ($get_id <= 0) {
        die("<meta charset='UTF-8'> Ты ахуел в край!!!");
    }
    $user_id = $user ? (int)$user['id'] : 0;
    if ($get_id === $user_id && $user) {
        $profile = $user;
    }
    else{
        $profile = not_current_user_by_id($db, $get_id);
    }
?>

<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo $profile ? htmlspecialchars($profile['username']) : 'Профиль'; ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="topbar">
    <div class="brand">БисЧан</div>
    <nav class="nav">
        <a href="index.php">Главная</a>
        <?php if ($user): ?>
            <a href="new_topic.php">Новая тема</a>
            <?php if (is_admin($user)): ?>
                <a href="admin.php">Админка</a>
            <?php endif; ?>
            <a href="logout.php">Выйти</a>
        <?php else: ?>
            <a href="login.php">Вход</a>
            <a href="register.php">Регистрация</a>
        <?php endif; ?>
    </nav>
</header>
    <?php if ($uploadError): ?>
        <div class="error"><?= htmlspecialchars($uploadError) ?></div>
    <?php elseif ($uploadMessage): ?>
        <div class="empty"><?= htmlspecialchars($uploadMessage) ?></div>
    <?php endif; ?>
    <?php if($profile) { ?>
    <div style="border: solid">
    <?php echo "<img width='10%' height='10%' src='".htmlspecialchars(avatar_url($profile))."'>" ?>
    <?php 
    $color_username = '';
    if(is_admin($profile)){$color_username='red';}
    ?>
    <?php
    $displayName = isset($profile['display_name']) && $profile['display_name'] !== '' ? $profile['display_name'] : $profile['username'];
    $createdAt = isset($profile['created_at']) ? $profile['created_at'] : '';
    echo '<b style="font-size: 30px;position: absolute;color:'.$color_username.';">'. htmlspecialchars($displayName) .'</b>
    <span style="font-size: 20px;margin-top: 50px;position: absolute;">Имя пользователя: '. htmlspecialchars($profile['username']) .'</span>
    <span style="font-size: 20px;margin-top: 100px;position: absolute;">Аккаунт создан: '. htmlspecialchars($createdAt) .'</span>'; ?>
    </div>
    <?php if ($get_id == $user_id) { ?>
        <form method="post" enctype="multipart/form-data" class="form" style="margin-top: 16px;">
            <label>
                Аватар
                <input type="file" name="avatar" accept="image/*" required>
            </label>
            <input type="hidden" name="user_id" value="<?= (int)$user_id ?>">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
            <button type="submit">Загрузить</button>
        </form>
    <?php }elseif($get_id != $user_id && count($profile) != 0){ ?>
    <!-- вывод того, когда находимся на страничке у кого-то -->
    Как тебе форумчанен?))))
    <?php } ?>
    <?php }else{ ?>
    <?php die('Не, ну ты чето дохуя ахуеваешь');} ?>
</body>
</html>
